public class task77 {
    public static void main(String[] args) {
        int city = 10000000;
        int deth =14;
        int dorn = 8;
        int kpd = 10000;
        int year = 10;
        int solution = city - 6* kpd*year;
        System.out.println(solution);


    }
}
